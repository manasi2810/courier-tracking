
<?php $__env->startSection('content'); ?>
		<div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-12 col-sm-6">
                  <h3>Service Tracking</h3>
                </div>
                <div class="col-12 col-sm-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('CustomerSupport-dashboard')); ?>">                                       <i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item"> Service Tracking</li>
                    
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('CustomerSupport.layout.formapp', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SRBcomputer\resources\views/CustomerSupport/servicetracking.blade.php ENDPATH**/ ?>