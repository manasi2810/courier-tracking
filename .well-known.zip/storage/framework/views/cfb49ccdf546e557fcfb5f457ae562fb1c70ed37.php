
<?php $__env->startSection('content'); ?>
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-12 col-sm-6">
                  <h3>Desktop</h3>
                </div>
                <div class="col-12 col-sm-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('CustomerSupport-dashboard')); ?>">                                       <i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item"> Service Layout</li>
                    <li class="breadcrumb-item active">Desktop</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
             
              <div class="col-sm-12">
                <div class="row">
                  <div class="col-sm-12">
                    <div class="card">
                      <div class="card-header pb-0">
                        <h5>Service form</h5>
                      </div>
                      <div class="card-body">
                        <form class="theme-form mega-form">
                          <?php echo csrf_field(); ?>
                          <h6>Customer Information</h6>
                          <div class="mb-3">
                            <label class="col-form-label">Customer Name</label>
                            <input class="form-control" type="text" placeholder="Customer Name">
                          </div>
                          <div class="mb-3">
                            <label class="col-form-label">Company Name</label>
                            <input class="form-control" type="text" placeholder="Company Name">
                          </div>
                          <div class="mb-3">
                            <label class="col-form-label">Email Address</label>
                            <input class="form-control" type="email" placeholder="Enter email">
                          </div>
                          <div class="mb-3">
                            <label class="col-form-label">Contact Number</label>
                            <input class="form-control" type="text" pattern="[7-9]{1}[0-9]{9}" placeholder="Enter contact number" maxlength="10">
                          </div>
                          <div class="mb-3">
                            <label class="col-form-label">Alternate Contact Number</label>
                            <input class="form-control" type="text" pattern="[7-9]{1}[0-9]{9}" placeholder="Enter contact number" maxlength="10">
                          </div>
                          <div class="mb-3">
                            <label class="col-form-label">Address</label>
                            <textarea class="form-control" rows="3" placeholder="Enter Complete Address"></textarea>
                          </div>
                          <div class="mb-3">
                            <label class="col-form-label">Pincode </label>
                            <input class="form-control" type="text" pattern="[4]{1}[0-9]{5}" placeholder="Enter Pincode" maxlength="6">
                          </div>
                          <div class="mb-3">
                            <label class="col-form-label">City</label>
                            <select class="form-control">
                              <option>Please Select</option>
                            </select>
                          </div>
                          <div class="mb-3">
                            <label class="col-form-label">Zone</label>
                            <select class="form-control">
                              <option>Please Select</option>
                            </select>
                          </div>

                        <hr class="mt-4 mb-4">
                        <h6>Billing Information</h6>

                         <div class="mb-3">
                            <label class="col-form-label">Problem</label>
                            <textarea class="form-control" rows="3" placeholder="Enter Problem"></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="col-form-label">Product Require</label>
                            <textarea class="form-control" rows="2" placeholder="Enter Requirement"></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="col-form-label">Date & Time [Clint Prefered]</label>
                            <input class="form-control digits" type="text" name="daterange2" value="01/11/2022 1:30 PM - 01/11/2022 2:00 PM">
                        </div>
                        <div class="mb-3">
                            <label class="col-form-label">Payment Mode</label>
                            <select class="form-control">
                              <option>Please Select</option>
                              <option>AMC (Annual Maintinance Contract)</option>
                              <option>UPI</option>
                              <option>A/c refer</option>
                              <option>Cash</option>
                              
                            </select>
                        </div>
                       
                      
                        <div class="mb-3">
                            <label class="col-form-label">Remark</label>
                            <textarea class="form-control" rows="2" placeholder="Enter Other Remark"></textarea>
                        </div>
                      </div>
                      <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button class="btn btn-secondary">Cancel</button>
                      </div>
                      </form>
                    </div>
                  </div>
                
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('CustomerSupport.layout.formapp', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SRBcomputer\resources\views/CustomerSupport/services/DesktopForm.blade.php ENDPATH**/ ?>