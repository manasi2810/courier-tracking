 

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Couriers</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Couriers</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">

            <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Quick Create</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST" action="<?php echo e(route('Booking.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                  <div class="form-group">
                    <label for="forwordingno">Forwording No</label>
                    <input type="text" class="form-control" name="forwordingno"  id="forwordingno" placeholder="Enter Forwording no" required>
                  </div>
                  <div class="form-group">
                    <label for="pickuplocation">Pickup Location</label>
                    <input type="text" class="form-control" name="pickuplocation"  id="pickuplocation" placeholder="Enter Pickup Location" required>
                  </div>
                  <div class="form-group">
                    <label for="deliverylocation">Delivery Location</label>
                    <input type="text" class="form-control" name="deliverylocation"  id="deliverylocation" placeholder="Enter Delivery Location" required>
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->

         
          </div>





          <div class="col-12">
            <div class="card">
             
                

              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Forwording No</th>
                    <th>Pickup Location</th>
                    <th>Delivery Location</th>
                    <th>Last Location</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <!-- <th>Active</th> -->
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
            <?php if(count($datas) > 0): ?>
            <?php ($i = 1); ?>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($data->forwordingno); ?></td>
                    <td><?php echo e($data->pickuplocation); ?></td>
                    <td><?php echo e($data->deliverylocation); ?></td>
                    <?php $location = DB::table('bookinglog')->where('bookingno',$data->id)->orderBy('created_at', 'desc')->first();?>
                    <td><?php echo e($location->currentstatus); ?></td>
                    <td><?php echo e($data->status); ?></td>
                    <td><?php echo e($data->created_at); ?></td>

                   <!--  <td><label class="switch">
                    <input type="checkbox">
                    <span class="slider round"></span>
                    </label></td> -->
                    <td>
                      <?php if($data->status !="Delivered"): ?>
                      <a href="<?php echo e(route('Booking.show',$data->id)); ?>" class="btn btn-app"><i class="fas fa-edit"></i> Edit</a>
                    <?php endif; ?>
                  </td>
                  </tr>
            <?php ($i++); ?>   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>#</th>
                    <th>Forwording No</th>
                    <th>Pickup Location</th>
                    <th>Delivery Location</th>
                    <th>Last Location</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <!-- <th>Active</th> -->
                    <th>Action</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

           
          
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.tabelapp', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SBexpress\resources\views/admin/booking/bookings.blade.php ENDPATH**/ ?>