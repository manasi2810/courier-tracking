 

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Pincode </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Pincode</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
   <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div onclick="toggleDiv()" class="card-header">
                <h3 class="card-title">Pincode</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
           
                    <div id="ouickform" style="display: none;">
              <form method="POST" action="<?php echo e(route('pincode.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="row">
                    <div class="col-md-4">
                    <div class="form-group">
                    <label for="booking_office">Pincode</label>
                    <input type="text" class="form-control" name="pincode"  id="pincode" required>
                  </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                    <label for="booking_date">City</label>
                    <input type="text" class="form-control" name="city"  id="city" required>
                  </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                    <label for="booking_date">State</label>
                    <input type="text" class="form-control" name="state"  id="state" required>
                  </div>
                  </div>
                    </div>
 
                </div>
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
              </div>
              <script>
                    function toggleDiv() {
                        var div = document.getElementById("ouickform");
                        if (div.style.display === "none" || div.style.display === "") {
                            div.style.display = "block";
                        } else {
                            div.style.display = "none";
                        }
                    }
                </script>
            </div>
            <!-- /.card -->
          </div>
               <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div onclick="toggleDivbulk()" class="card-header">
                <h3 class="card-title">Bulk Pincode Upload </h3>
              </div>
              <!-- /.card-header -->
                <div class="card-body" id="bulk" style="display: none;">
                <div class="row">
                    <div class="col-md-12">
                        <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header" style="background-color: #fff;color: black;">
                <h3 class="card-title">Bulk Upload</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST" action="<?php echo e(route('BulkPincode')); ?>" enctype="multipart/form-data" onsubmit="disableSubmitButton()">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                  <div class="form-group">
                        <label for="exampleInputFile"><a href="https://track.sbexpresscargo.com/storage/BulkPincode.xlsx" download="BulkPincode.xlsx">Download Format</a></label>
                        
                        <div class="input-group">
                        <div class="custom-file">
                        <input name="excel_file" type="file" class="custom-file-input" id="exampleInputFile">
                        <label class="custom-file-label" for="exampleInputFile">Choose file to create </label>
                        </div>
                        </div>
                        </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary" id="submit-btn">Create</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
                </div> 
                </div>
                </div>
                <script>
                    function toggleDivbulk() {
                        var div = document.getElementById("bulk");
                        if (div.style.display === "none" || div.style.display === "") {
                            div.style.display = "block";
                        } else {
                            div.style.display = "none";
                        }
                    }
                </script>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div> 
          <div class="col-12">
            <div class="card">
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Pincode</th>
                    <th>City</th> 
                    <th>State</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                   <?php if(count($datas) > 0): ?>
            <?php ($i = 1); ?>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($data->pincode); ?></td>
                    <td><?php echo e($data->city); ?></td>
                    <td><?php echo e($data->state); ?></td>
                    <td>
                     <form method="post" action="<?php echo e(route('pincode.destroy',$data->id)); ?>">
                         <a href="<?php echo e(route('pincode.show',$data->id)); ?>" class="btn btn-sm"><i class="fas fa-edit"></i>Edit</a>
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm"><i class="fas fa-trash"></i>Delete</button>
                        </form>
                    </td>
                  </tr>
            <?php ($i++); ?>   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
             
                  <tfoot>
                  <tr>
                   <th>#</th>
                    <th>Pincode</th>
                    <th>City</th> 
                    <th>State</th>
                    <th>Action</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

           
          
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.tabelapp', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sbfasto/track.sbexpresscargo.com/resources/views/admin/pincode/index.blade.php ENDPATH**/ ?>